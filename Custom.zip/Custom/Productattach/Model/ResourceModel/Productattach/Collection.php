<?php
namespace Custom\Productattach\Model\ResourceModel\Productattach;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'productattach_id';
    protected function _construct()
    {
        $this->_init('Custom\Productattach\Model\Productattach','Custom\Productattach\Model\ResourceModel\Productattach');
    }
}