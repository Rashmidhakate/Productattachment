<?php
namespace Custom\Productattach\Block\Adminhtml\Productattach\Renderer;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\Object;
use Magento\Store\Model\StoreManagerInterface;

class Productattach extends \Magento\Framework\Data\Form\Element\AbstractElement
{
  public function getElementHtml(){
    $_objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of\Magento\Framework\App\ObjectManager
    $storeManager = $_objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
    $currentStore = $storeManager->getStore();
    $mediaUrl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA); 
    $fileValue = $this->getValue();
    if($fileValue){
      echo $fileValue."<br>";
      $fileExt = pathinfo($fileValue, PATHINFO_EXTENSION);
      $file='';
      $extensionArray = ["pdf","csv","txt"];
      if(in_array($fileExt, $extensionArray)){
        $fileUrl = $mediaUrl.'productattachment/documents/'.$fileValue;
        $file = '<a href="'.$fileUrl.'" target="_blank" download>Open File</a>';
      }elseif($fileExt == "mp4"){
        $fileUrl = $mediaUrl.'productattachment/videos/'.$fileValue;
        $file = '<video width="320" height="240" controls autoplay><source src="'.$fileUrl.'" type="video/mp4"></video>';
      }else{
        $fileUrl = $mediaUrl.'productattachment/'.$fileValue;
        $file = '<a href="'.$fileUrl.'" target="_blank" download>Open File</a>';
      }
      $file .= '<a href="">Delete File</a>';
    }
    return $file;
  }
}