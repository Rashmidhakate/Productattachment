<?php
namespace Custom\Productattach\Controller\Adminhtml\Index;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Framework\Filesystem;

class Save extends \Magento\Backend\App\Action
{
    protected $cacheTypeList;
    protected $jsHelper;

    const ADMIN_RESOURCE = 'Custom_Productattach::save';
    protected $adapterFactory;
    protected $uploader;
    protected $filesystem;


    protected $_filesystem;
    protected $_storeManager;
    protected $_directory;
    protected $_imageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Backend\Helper\Js $jsHelper,
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploader,        
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Image\AdapterFactory $imageFactory
    )
    {        
        $this->_storeManager = $storeManager;
        $this->_directory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;
        $this->adapterFactory = $adapterFactory;
        $this->uploader = $uploader;
        $this->filesystem = $filesystem;
        $this->cacheTypeList = $cacheTypeList;
        parent::__construct($context);
        $this->jsHelper = $jsHelper;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        $file = $this->getRequest()->getFiles('file');
        
        if ($data) {
            
            $model = $this->_objectManager->create('Custom\Productattach\Model\Productattach');

            $id = $this->getRequest()->getParam('productattach_id');
            if ($id) {
                $model->load($id);
            }
            if($file && $file["size"] < 5242880){

                if($file["type"] == 'text/csv' || $file["type"] == 'application/pdf' || $file["type"] == 'text/plain')
                { 
                    //echo $file["type"];
                    $target = $this->_directory->getAbsolutePath('productattachment/documents/');
                    //echo $target;
                }elseif($file["type"] == 'video/mp4'){
                    //echo $file["type"];
                    $target = $this->_directory->getAbsolutePath('productattachment/videos/');
                }else{
                    //echo $file["type"];
                    $target = $this->_directory->getAbsolutePath('productattachment/');
                }               
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->uploader->create(
                    ['fileId' => 'file']
                );
                $uploader->setAllowedExtensions(
                    ['jpg', 'jpeg', 'gif', 'png','doc','pdf','xls','docx','zip','mp4','avi','mp3','txt','xlsx','vob','csv','gif']
                );
                $uploader->setAllowRenameFiles(true);
                $uploader->save($target);
                chmod($target.'/'.$file["name"], 0777);
            }
            else{
                $this->messageManager->addError("Please Upload file less than 2MB");
                return $resultRedirect->setPath('*/*/edit', ['productattach_id' => $model->getId(), '_current' => true]);
            }
            //exit;
            if($data["products"]){
                $new_prd_string = '';
                if(!empty($data["products"]) && strpos($data["products"], '&')){
                    $prd_array = explode('&',$data["products"]);    
                    $new_prd_string = implode(',', $prd_array);
                } else {
                    $new_prd_string = $data['products'];
                }
            }
            $model->setName($data["name"]);
            $model->setDescription($data["description"]);
            $model->setUrl($data["url"]);
            $model->setCustomerGroup(implode(',', $data["customer_group"]));
            $model->setStore(implode(',', $data["store"]));
            $model->setActive($data["active"]);
            $model->setFile($file["name"]);
            $model->setFileExt($file["type"]);
            $model->setProducts($new_prd_string);  
            try {
                $model->save();
                $this->cacheTypeList->invalidate('full_page');
                $this->messageManager->addSuccess(__('You saved this Attachment.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['productattach_id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Attachment.'));
            }

            return $resultRedirect->setPath('*/*/edit', ['productattach_id' => $this->getRequest()->getParam('productattach_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function getDestinationPath()
    {
        return $this->filesystem
            ->getDirectoryWrite(DirectoryList::TMP)
            ->getAbsolutePath('productattachment/');
    }


}
