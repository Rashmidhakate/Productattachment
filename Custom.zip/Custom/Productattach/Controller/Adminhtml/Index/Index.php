<?php
namespace Custom\Productattach\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
	private $resultPageFactory;
	public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Custom_Productattach::manage');
    }

    public function execute(){
    	$resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu(
            'Prince_Productattach::productattach_manage'
        )->addBreadcrumb(
            __('Attachment'),
            __('Attachment')
        )->addBreadcrumb(
            __('Manage Attachment'),
            __('Manage Attachment')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Product Attachment'));
        return $resultPage;
    }
}